Dear Developers,
	This extension will place whatever .dll files you package Into TCG Card Shop Simulator/BepInEx/Plugins
	All other file types (such as .png, .txt, .obj, etc.) will need to be structured exactly as the game is.
	
	Examples:
	.assets or .resource: \Card Shop Simulator_Data\files here
	.png: \BepInEx\plugins\TextureReplacer\objects_textures\files here
	.obj: \BepInEx\plugins\TextureReplacer\meshes\files here
	

	Also Includes a BepInEx CFG To make sure config manager will work natively.

	Please feel free to reach out to us if you have any questions.
	
Regards,
	RedFog18 and Flugelwulff