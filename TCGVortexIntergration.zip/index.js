const path = require('path');
const { fs, log, util } = require('vortex-api');
// Nexus Mods domain for the game. e.g. nexusmods.com/bloodstainedritualofthenight
const GAME_ID = 'tcgcardshopsimulator';

//Steam Application ID, you can get this from https://steamdb.info/apps/
const STEAMAPP_ID = '3070070';

function main(context) {
	//This is the main function Vortex will run when detecting the game extension.
	//context.requireExtension('modtype-bepinex');
	context.once(() => {
		// The context.once higher-Order function ensures that we only call items
		//  within this code block ONCE which makes it a perfect block to initialize
		//  functionality; which is why we've added the BepInEx registration function
		//  here - but theoretically you could do this during the game extension's
		//  setup functor too.
		if (context.api.ext.bepinexAddGame !== undefined) {
			context.api.ext.bepinexAddGame({
				gameId: GAME_ID,
				autoDownloadBepInEx: true,
				architecture: 'x64',
				//bepinexVersion: '5.4.23.2',
				forceGithubDownload: true, // <--- This will force Vortex to download directly from Github
				unityBuild: 'unitymono',
			})
		}
	})
	context.registerGame({
		id: GAME_ID,
		name: 'TCG Card Shop Simulator',
		mergeMods: true,
		queryPath: findGame,
		supportedTools: [],
		queryModPath: () => '',
		logo: 'gameart.png',
		executable: () => 'Card Shop Simulator.exe',
		requiredFiles: [
			'Card Shop Simulator.exe',
			'UnityPlayer.dll',
		],
		setup: prepareForModding,
		environment: {
			SteamAPPId: STEAMAPP_ID,
		},
		details: {
			stopPatterns:[
				'(^|/)Card Shop Simulator_Data(/|$)',
				'(^|/).*\.([^.]+)$'
			],
		},
	});
	
	
	return true;
}

function findGame() {
	return util.GameStoreHelper.findByAppId([STEAMAPP_ID])
	.then(game => game.gamePath);
}

function prepareForModding(discovery) {
	return fs.ensureDirWritableAsync(path.join(discovery.path, 'BepInEx'));
}

module.exports = {
	default: main,
};